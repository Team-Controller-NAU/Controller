#include "mainwindow.h"
#include <QTextDocument>
#include <QTextCursor>

/********************************************************************************
** mainwindow.cpp
**
** The MainWindow class implements the main window of the entire software. It manages
** the user interface and coordinates interactions between various components of the software,
** including serial communication, status updates, event logging, electrical data management,
** and user settings.
**
** @author Team Controller
********************************************************************************/

/**
 * @brief Constructor for MainWindow Class
 *
 * Sets up the entire application and GUI window to default initialization values
 *
 * @param parent Pointer to the parent widget
 */
MainWindow::MainWindow(QWidget *parent)

    //initialize imbedded classes/vars
    : QMainWindow(parent),
    ui(new Ui::MainWindow),
    ddmCon(nullptr),
    status(new Status()),
    electricalData(new electrical()),
    events(nullptr),

    //this determines what will be shown on the events page
    eventFilter(ALL),

    //timer is used to repeatedly transmit handshake signals
    handshakeTimer( new QTimer(this) ),

    //timer is used to hide notifications some time after they are displayed
    notificationTimer(new QTimer(this)),

    // timer is used to update last message received time
    lastMessageTimer( new QTimer(this) ),

    // timer is used to update controller running time
    runningControllerTimer( new QTimer(this) ),

    //timer for preventing spam of handshake button
    handshakeCooldownTimer(new QTimer(this)),

    //init user settings to our organization and project
    userSettings("Team Controller", "WSSS"),

    //init to false until connection page is setup
    allowSettingChanges(false),

    //Load graphical resources
    BLANK_LIGHT(":/resources/Images/blankButton.png"),

    RED_LIGHT(":/resources/Images/redButton.png"),

    GREEN_LIGHT(":/resources/Images/greenButton.png"),

    ORANGE_LIGHT(":/resources/Images/orangeButton.png")
{
    //init gui
    ui->setupUi(this);

    //setup user settings and init settings related gui elements
    setupSettings();

    //make new events class for this session
    events = new Events(userSettings.value("RAMClearing").toBool(), userSettings.value("maxDataNodes").toInt());

    //setup signal and slot to notify user when ram is cleared from events
    //this signal connects to a lambda function so we can call more than 1 function
    //using 1 signal-slot connection
    connect(events, &Events::RAMCleared, this, &MainWindow::handleRAMClear);

    //will be disabled until RAM is cleared
    ui->truncated_label->setVisible(false);

    //if dev mode is active, init CSim
    #if DEV_MODE

        //set output settings for qDebug
        qSetMessagePattern(QDEBUG_OUTPUT_FORMAT);

        #if GENERAL_DEBUG
        qDebug() << "Dev mode active";
        #endif

        //get csimPortName from port selection
        csimPortName = ui->csim_port_selection->currentText();

        //init csim class, assign serial port
        csimHandle = new CSim(nullptr, csimPortName);

        //init generation interval
        csimHandle->generationInterval = CSIM_GENERATION_INTERVAL;
        ui->csim_generation_interval_selection->setValue(csimHandle->generationInterval);

        //CSIM control slots ==============================================================

        //connect custom transmission requests from ddm to csims execution slot
        connect(this, &MainWindow::transmissionRequest, csimHandle, &CSim::completeTransmissionRequest);

        //connect custom clear error requests from ddm to csims execution slot
        connect(this, &MainWindow::clearErrorRequest, csimHandle, &CSim::clearError);

        //connect output session string to ddm output session string slot
        connect(this, &MainWindow::outputMessagesSentRequest, csimHandle, &CSim::outputMessagesSent);
        //=================================================================================
    //dev mode is not active, hide dev page button
    #else
        ui->DevPageButton->setVisible(false);
    #endif

    //Timers ===============================================================================

    //set handshake timer interval
    handshakeTimer->setInterval(HANDSHAKE_INTERVAL);

    //connect handshake function to a timer. After each interval handshake will be called.
    //this is necessary to prevent the gui from freezing. signals stop when timer is stoped
    connect(handshakeTimer, &QTimer::timeout, this, &MainWindow::handshake);

    //prevents spamming of the handshake button which may cause crash
    handshakeCooldownTimer->setInterval(HANDSHAKE_COOLDOWN_TIME);
    handshakeCooldownTimer->setSingleShot(true);

    //connect clear notification process to the notification timer. If run, the process
    //will trigger after the notification timeout
    connect(notificationTimer, &QTimer::timeout, this, [this]() {
        ui->notificationPopUp->setStyleSheet(INVISIBLE);
        ui->notificationPopUp->clear();
    });

    // connect update elapsed time function to a timer
    lastMessageTimer->setInterval(ONE_SECOND);
    connect(lastMessageTimer, &QTimer::timeout, this, &MainWindow::updateTimeSinceLastMessage);

    //connect running controller timer to slot
    runningControllerTimer->setInterval(ONE_SECOND);
    connect(runningControllerTimer, &QTimer::timeout, this, &MainWindow::updateElapsedTime);
    //======================================================================================

    //init trigger to grey buttons until updated by serial status updates
    ui->trigger1->setPixmap(BLANK_LIGHT);
    ui->trigger2->setPixmap(BLANK_LIGHT);

    // ensures that the application will open on the connection page
    on_ConnectionPageButton_clicked();
}

/**
 * @brief Destructor
 */
MainWindow::~MainWindow()
{
    //call destructors for classes declared in main window
    delete ui;
    delete ddmCon;
    delete status;
    delete events;
    delete handshakeTimer;
    delete notificationTimer;
    delete lastMessageTimer;
    delete runningControllerTimer;
    delete handshakeCooldownTimer;
    delete electricalData;
    #if DEV_MODE
        delete csimHandle;
    #endif
}

/**
 * @brief Updates the connection status and associated GUI elements/timers
 *
 * This occurs whenever we want to change our status between disconnected or
 * connected. It updates relevant GUI elements to reflect the current connection state.
 *
 * @param connectionStatus The status of the connection (true for connected)
 */
void MainWindow::updateConnectionStatus(bool connectionStatus)
{
    if (ddmCon == nullptr)
    {
        return;
    }

    //update connection status
    ddmCon->connected = connectionStatus;

    //check if we are connected
    if (ddmCon->connected)
    {
        //disable changes to connection related settings
        disableConnectionChanges();

        //stop handshake protocols
        handshakeTimer->stop();

        ui->truncated_label->setVisible(false);

        // check if controller timer is not running
        if(!runningControllerTimer->isActive())
        {
            // start it
            runningControllerTimer->start();

            // update elapsed time
            ui->elapsed_time_label->setText("Elapsed Time: ");
            ui->elapsedTime->setText( status->elapsedControllerTime.toString(TIME_FORMAT));
        }

        //free all elements of electrical page if they exist
        freeElectricalPage();

        //free old electrical data if any exists
        electricalData->freeLL();

        //start last message timer
        timeLastReceived = QDateTime::currentDateTime();
        ui->DDM_timer_label->setText("Time Since Last Message :");
        ui->DDMTimer->setText("00:00:00");
        lastMessageTimer->start();

        // update ui
        ui->handshake_button->setText("Disconnect");
        ui->handshake_button->setStyleSheet(CONNECTED_STYLE);
        ui->connectionLabel->setText("Connected ");
        ui->connectionStatus->setPixmap(GREEN_LIGHT);

        //clear events and full clear the class output box
        ui->events_output->clear();

        events->freeLinkedLists(true);

        //reset event counters
        ui->TotalEventsOutput->setText("0");
        ui->statusEventOutput->setText("0");

        ui->TotalErrorsOutput->setText("0");
        ui->statusErrorOutput->setText("0");

        ui->ClearedErrorsOutput->setText("0");

        ui->ActiveErrorsOutput->setText("0");
    }
    //otherwise we are disconnected
    else
    {
        //stop timers if they are running
        runningControllerTimer->stop();
        lastMessageTimer->stop();
        handshakeTimer->stop();

        //clear time since last message
        ui->DDMTimer->clear();
        ui->DDM_timer_label->clear();

        //enable changes to connection related settings
        enableConnectionChanges();

        //refreshes connection button/displays
        ui->handshake_button->setText("Connect");
        ui->handshake_button->setStyleSheet(DISCONNECTED_STYLE);
        ui->connectionStatus->setPixmap(RED_LIGHT);
        ui->connectionLabel->setText("Disconnected ");

        //output session stats
        if (autosaveLogFile != "")
        {
            notifyUser("Session statistics ready", getSessionStatistics(), false);
        }

        //if advanced log file is enabled, add details to log file
        if (advancedLogFile)
        {
            logAdvancedDetails(ELECTRICAL);
            logAdvancedDetails(CLOSING_CONNECTION);
        }
    }
}

/**
 * @brief Creates a new Connection object for the selected DDM port
 *
 * When a new DDM port is selected from the dropdown menu, it creates a new
 * object and establishes the connection with the selected user settings
 */
void MainWindow::createDDMCon()
{
    //close current connection
    if (ddmCon != nullptr)
    {
        //notify user of closed connection class
        notifyUser(ddmPortName + " closed",  false);
        delete ddmCon;
        ddmCon = nullptr;
    }

    //open new connection
    ddmCon = new Connection(ui->ddm_port_selection->currentText(),
                            fromStringBaudRate(ui->baud_rate_selection->currentText()),
                            fromStringDataBits(ui->data_bits_selection->currentText()),
                            fromStringParity(ui->parity_selection->currentText()),
                            fromStringStopBits(ui->stop_bit_selection->currentText()),
                            fromStringFlowControl(ui->flow_control_selection->currentText()));

    if (ddmCon == nullptr)
    {
        notifyUser("Failed to open " + ui->ddm_port_selection->currentText(), true);
    }
    //check for failure to open
    else if (!ddmCon->serialPort.isOpen())
    {
        delete ddmCon;
        ddmCon = nullptr;

        //generate notification
        notifyUser("Failed to open " + ui->ddm_port_selection->currentText(), true);
    }
    else
    {
        //set up signal and slot (when a message is sent to DDMs serial port, the readyRead signal is emitted and
        //readSerialData() is called)
        connect(&ddmCon->serialPort, &QSerialPort::readyRead, this, &MainWindow::readSerialData);

        qDebug() << "GUI is now listening to port " << ddmCon->portName;

        notifyUser(ui->ddm_port_selection->currentText() + " opened", false);
    }
}

/**
 * @brief Performs the initial synchronization between the controller and DDM
 */
void MainWindow::handshake()
{
    if (ddmCon == nullptr)
    {
        // notify of handshake failure
        notifyUser("Handshake failed", "Connection class is not declared", true);
        return;
    }

    // send handshake message if Con object ready
    ddmCon->sendHandshakeMsg();
}

/**
 * @brief Reads and processes incoming serial data from the DDM port
 *
 * This method is called as a result of the readyRead signal being emitted by
 * a connected serial port, indicating that new data has been received. It processes
 * the incoming data, identifies the type of message, and performs the corresponding
 * actions based on the message type.
 *
 * It reads lines from the serial port until all data in the buffer is processed. Depending
 * on the message type, it may update the GUI, data structures, log file, etc.
 *
 * This method is also the point at which errors are handled by invalid messages or
 * unexpected input, and the load() methods that are ran redudantly check as well.
 */
void MainWindow::readSerialData()
{
    if (ddmCon == nullptr)
    {
        //this should never happen..
        qDebug() <<"Error: readSerialData called with no connection class declared"<<Qt::endl;
        notifyUser("Could not read serial data", "Connection class is not declared", true);
        return;
    }

    //prevent timeout during long processing
    lastMessageTimer->stop();

    //read lines until all data in buffer is processed
    while (ddmCon->checkForValidMessage() == VALID_MESSAGE)
    {
        // declare variables
        SerialMessageIdentifier messageId;
        int errorId;
        int result;

        //get serialized string from port
        QByteArray serializedMessage = ddmCon->serialPort.readLine();

        //deserialize string
        QString message = QString::fromUtf8(serializedMessage);

        #if DEV_MODE && SERIAL_COMM_DEBUG
        qDebug() << "message: " << message;
        #endif
        #if DEV_MODE
        //update gui with new message
        ui->stdout_label->setText(message);
        #endif

        //check if message id is present and followed by the proper delimeter
        if (message[0].isDigit() && message[1] == DELIMETER)
        {
            //extract message id
            messageId = static_cast<SerialMessageIdentifier>(QString(message[0]).toInt());

            //ensure we are in an active connection or attempting to connect
            if(!(handshakeTimer->isActive() || ddmCon->connected))
            {
                qDebug() << "Error: readSerialData unexpected communication from controller"<< Qt::endl;
                notifyUser("Unexpected communication from controller", message, true);
                ddmCon->sendDisconnectMsg();
                return;
            }
            //ensure we are only getting begin message during handshake
            else if (handshakeTimer->isActive() && messageId != BEGIN)
            {
                notifyUser("Invalid handshake is occurring", message, true);
                ddmCon->sendDisconnectMsg();
                return;
            }

            //remove message id from message (id has len=1 and delimeter has len=1 so 2 total)
            message = message.mid(2);

            //determine what kind of message this is
            switch ( messageId )
            {
            case STATUS:
                // STATUS MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() <<  "Message id: status update" << qPrintable("\n");
                #endif

                //update status class with new data
                if (!status->loadData(message))
                {
                    notifyUser("Invalid status message received", message, true);
                }

                //update gui
                updateStatusDisplay();

                //if advanced log file is enabled, log the status
                if (advancedLogFile) logAdvancedDetails(STATUS);

                break;

            case EVENT:
                // EVENT MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() <<  "Message id: event update" << qPrintable("\n");
                #endif

                //add new event to event ll, check for fail
                if (!events->loadEventData(message))
                {
                    notifyUser("Invalid event message received", message, true);
                }
                //otherwise success
                else
                {
                    // update log file
                    events->appendToLogfile(autosaveLogFile, events->lastEventNode);

                    // update GUI elements
                    updateEventsOutput(events->lastEventNode);
                }

                break;

            case ERROR:
                // ERROR MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() <<  "Message id: error update" << qPrintable("\n");
                #endif

                //add new error to error ll, check for fail
                if (!events->loadErrorData( message ))
                {
                    notifyUser("Invalid error message received", message, true);
                }
                //otherwise success
                else
                {
                    // update log file
                    events->appendToLogfile(autosaveLogFile, events->lastErrorNode);

                    //update gui elements
                    updateEventsOutput(events->lastErrorNode);

                    #if DEV_MODE
                        //update the cleared error selection box in dev tools
                        //(this can be removed when dev page is removed)
                        update_non_cleared_error_selection();
                    #endif
                }

                break;

            case ELECTRICAL:
                // ELECTRICAL MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() <<  "Message id: electrical" << qPrintable("\n");
                #endif

                //load new data into electrical ll, notify if fail
                if (!electricalData->loadElecDump(message))
                {
                    notifyUser("Invalid electrical dump received", message, true);
                }
                //otherwise success
                else
                {
                    //dynamically generate nodes on electrical page
                    renderElectricalPage();
                }

                break;

            case EVENT_DUMP:
                // EVENT DUMP MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() <<  "Message id: event dump" << qPrintable("\n");
                #endif

                // load all events to event linked list, notify if fail
                if (!events->loadEventDump(message))
                {
                    notifyUser("Invalid event dump received", message, true);
                }
                else if (events->totalEvents == 1)
                {
                    notifyUser(QString::number(events->totalEvents) + " event loaded from dump", false);
                }
                else if (events->totalEvents > 0)
                {
                    notifyUser(QString::number(events->totalEvents) + " events loaded from dump", false);
                }

                // create log file
                if (!events->outputToLogFile( autosaveLogFile, advancedLogFile ))
                {
                    notifyUser("Failed to open logfile","Manual download could save the data.", true);
                }

                //new auto save file created, enforce auto save limit
                enforceAutoSaveLimit();

                //refresh the events output with dumped event data
                refreshEventsOutput();

                break;

            case ERROR_DUMP:
                // ERROR DUMP MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() <<  "Message id: error dump" << qPrintable("\n");
                #endif

                // load all errors to error linked list, notify if fail
                if (!events->loadErrorDump(message))
                {
                    notifyUser("Invalid error dump received", message, true);
                }
                else if (events->totalErrors == 1)
                {
                    notifyUser(QString::number(events->totalEvents) + " error loaded from dump", false);
                }
                else if (events->totalErrors > 0)
                {
                    notifyUser(QString::number(events->totalEvents) + " errors loaded from dump", false);
                }

                // create log file
                if (!events->outputToLogFile( autosaveLogFile, advancedLogFile ))
                {
                    notifyUser("Failed to open logfile","Manual download could save the data.", true);
                }

                //new auto save file created, enforce auto save limit
                enforceAutoSaveLimit();

                //refresh the events output with dumped error data
                refreshEventsOutput();

                break;

            case CLEAR_ERROR:
                // CLEAR ERROR MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() << "Message id: clear error " << message << qPrintable("\n");
                #endif

                //extract error id from message
                errorId = message.left(message.indexOf(DELIMETER)).trimmed().toInt();

                //attempt clear
                result = events->clearError(errorId, autosaveLogFile );

                //check for fail (here failed to clear from ll indicates RAM dump)
                if (result != SUCCESS && result != FAILED_TO_CLEAR_FROM_LL)
                {
                    //notify user of fail type
                    if (result == FAILED_TO_CLEAR)
                    {
                        notifyUser("Failed to clear error", message, true);
                    }
                    else if (result == FAILED_TO_CLEAR_FROM_LOGFILE)
                    {
                        notifyUser("Error "+ QString::number(errorId) + " can't be cleared from logfile", true);
                    }
                }
                //otherwise success
                else
                {
                    //attempt to clear in events output
                    if (result == SUCCESS) clearErrorFromEventsOutput(errorId);

                    //update counters
                    ui->ClearedErrorsOutput->setText(QString::number(events->totalClearedErrors));
                    ui->statusClearedErrors->setText(QString::number(events->totalClearedErrors));

                    if (notifyOnErrorCleared) notifyUser("Error " + message.left(message.indexOf(DELIMETER)) + " Cleared", false);
                }

                #if DEV_MODE
                //update the cleared error selection box in dev tools (can be removed when dev page is removed)
                update_non_cleared_error_selection();
                #endif

                break;

            case BEGIN:
                // BEGIN MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() << "Message id: begin " << message << qPrintable("\n");
                #endif

                //load controller crc and version, check for fail
                if (!status->loadVersionData(message))
                {
                    //report
                    notifyUser("Invalid 'begin' message received", message, true);

                    //end connection attempt
                    ddmCon->sendDisconnectMsg();
                }
                //otherwise success
                else
                {
                    notifyUser("Handshake complete", "Session start", false);

                    //set connection status to connected and update related objects
                    updateConnectionStatus(true);

                    // update controller version and crc on gui
                    ui->controllerLabel->setText("Controller Version: " + status->version);
                    ui->crcLabel->setText("CRC: " + status->crc);

                    //init logfile location (user setting)
                    setup_logfile_location();

                    #if DEV_MODE && SERIAL_COMM_DEBUG
                    qDebug() << "Begin signal received, handshake complete";
                    #endif
                }

                break;

            case CLOSING_CONNECTION:
                // CLOSING MESSAGE TYPE
                #if DEV_MODE && SERIAL_COMM_DEBUG
                qDebug() << "Disconnect message received from Controller";
                #endif

                notifyUser("Controller disconnected", "Session end", false);

                //set connection status false and update related objects
                updateConnectionStatus(false);

                break;

            default:
                // invalid message id detected
                qDebug() << "ERROR: readSerialData message from controller is not recognized"<< Qt::endl;

                //report
                notifyUser("Unrecognized message received", QString::fromUtf8(serializedMessage), true);

                break;
            }
        }
        //invalid message id detected
        else
        {
            qDebug() << "Error: readSerialData Unrecognized serial message received : " << message<< Qt::endl;
            notifyUser("Unrecognized serial message received", QString::fromUtf8(serializedMessage), true);
        }
    }
    // end while loop checking for more data in buffer

    // update the timestamp of last received message
    timeLastReceived = QDateTime::currentDateTime();

    //re-enable timer
    lastMessageTimer->start();
}

/**
 * @brief Scans for available serial ports and populates the DDM port selection box
 *
 * This is only ran when the application starts or when the user interacts
 * with the port selection UI
 *
 * @param index The index of the DDM port selection box
 */
void MainWindow::setup_ddm_port_selection(int index)
{
    // Check and set initial value for "portName"
    if (userSettings.value("portName").toString().isEmpty())
        userSettings.setValue("portName", INITIAL_DDM_PORT);

    //this is checked within the current index changed slot of ddm combo box
    //start false prevents an accidental selection of the first
    //index added.
    allowSettingChanges = false;

    //clear any current selections
    ui->ddm_port_selection->clear();

    // Fetch available serial ports and add their names to the combo box
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QString portName = info.portName();
        ui->ddm_port_selection->addItem(portName);

        // Check if the current port name matches the one declared in settings
        if (portName == userSettings.value("portName").toString())
        {
            //allow us to select this port
            allowSettingChanges = true;

            // If a match is found, set the current index of the combo box
            ui->ddm_port_selection->setCurrentIndex(ui->ddm_port_selection->count() - 1);
        }
    }
    //initialization finished, allow port selection
    allowSettingChanges = true;
}

/**
 * @brief Disables all connection settings
 *
 * Usually used to prevent settings from being changed while a session is in progress
 */
void MainWindow::disableConnectionChanges()
{
    ui->ddm_port_selection->setDisabled(true);
    ui->baud_rate_selection->setDisabled(true);
    ui->data_bits_selection->setDisabled(true);
    ui->parity_selection->setDisabled(true);
    ui->stop_bit_selection->setDisabled(true);
    ui->flow_control_selection->setDisabled(true);
    ui->load_events_from_logfile->setDisabled(true);
    ui->restore_Button->setDisabled(true);
    ui->refresh_serial_port_selections->setVisible(false);
    ui->setLogfileFolder->setDisabled(true);
}

/**
 * @brief Enables all connection settings
 */
void MainWindow::enableConnectionChanges()
{
    ui->ddm_port_selection->setEnabled(true);
    ui->baud_rate_selection->setEnabled(true);
    ui->data_bits_selection->setEnabled(true);
    ui->parity_selection->setEnabled(true);
    ui->stop_bit_selection->setEnabled(true);
    ui->flow_control_selection->setEnabled(true);
    ui->load_events_from_logfile->setEnabled(true);
    ui->restore_Button->setEnabled(true);
    ui->refresh_serial_port_selections->setVisible(true);
    ui->setLogfileFolder->setEnabled(true);
}

/**
 * @brief Sets the log file directory
 *
 * This method checks if the user has set up a custom directory yet, and if not,
 * the default directory is used. This is the location where the auto-save and
 * manual log files will go for the session
 */
void MainWindow::setup_logfile_location()
{
    //initialize the logfile into preset directory
    autosaveLogFile = userSettings.value("logfileLocation").toString();

    //initialize a directory object in selected location
    QDir dir(autosaveLogFile);

    //check if directory doesnt exist
    if(!dir.exists())
    {
        //attempt to create the directory
        if(!dir.mkpath(autosaveLogFile))
        {
            qDebug() << "Error: setup_logfile_location Failed to create logfile folder on startup: " << autosaveLogFile<< Qt::endl;
            return;
        }
    }

    //if there are more auto saves than the current limit, delete the extras (oldest first)
    enforceAutoSaveLimit();

    // set unique logfile name for this session
    qint64 secsSinceEpoch = QDateTime::currentSecsSinceEpoch();
    autosaveLogFile += QString::number(secsSinceEpoch) + "-logfile-A.txt";

    notifyUser("Auto save log set", autosaveLogFile, false);
}

/**
 * @brief Enforces the auto-save limit for log files
 *
 * This method checks to see if the number of auto-saved log files in the
 * specified directory (from user settings) exceeds the user-set maximum. It will
 * delete the oldest log file so that the newest can replace it.
 */
void MainWindow::enforceAutoSaveLimit()
{
    QString path;

    //initialize the logfile into this directory
    path = userSettings.value("logfileLocation").toString();

    // Set a filter to display only files
    QDir dir(path);
    dir.setFilter(QDir::Files);

    // Get list of files in directory
    QStringList fileList = dir.entryList();

    // Create a new list to add auto save file names to
    QStringList autoSaveFileList;

    // Loop through names of files in directory
    for (const QString &fileName : fileList)
    {
        // Check if this is an auto save file
        if (fileName.endsWith("logfile-A.txt"))
        {
            // Append to the new list
            autoSaveFileList.append(fileName);
        }
    }

    // Delete the oldest file if the number of auto saved files is above the limit
    while (autoSaveFileList.size() > autoSaveLimit)
    {
        QString oldestFilePath;
        QDateTime oldestCreationTime;

        // Find the oldest file in the list
        for (const QString &autoSaveFile : autoSaveFileList)
        {
            // Get the path of the file
            QString filePath = dir.filePath(autoSaveFile);
            // Get the creation time of the file
            QFileInfo fileInfo(filePath);
            QDateTime creationTime = fileInfo.lastModified();

            // Check if this is the oldest file so far
            if (oldestCreationTime.isNull() || creationTime < oldestCreationTime)
            {
                oldestCreationTime = creationTime;
                oldestFilePath = filePath;
            }
        }

        // Remove the oldest file
        if (!QFile::remove(oldestFilePath))
        {
            qDebug() << "Error: enforceAutoSaveLimit failed to delete file: " << oldestFilePath << Qt::endl;
            return;
        }
        else
        {
            #if DEV_MODE && GENERAL_DEBUG
            qDebug() << "An autosave file was deleted: " << oldestFilePath;
            #endif
        }

        // Remove the oldest file name from the list
        autoSaveFileList.removeOne(QFileInfo(oldestFilePath).fileName());
    }
}

/**
 * @brief Sets up application settings and loads them into local variables
 *
 * This method checks if the registry values exist for the user settings. If not,
 * it sets their default values and loads them in to the registry and local variables
 * for later use (defined in constants.h).
 *
 * NOTE: Settings such as colored events output, auto save limit, connection timeout, RAM
 * clearing, etc. are initialized and loaded from the registry. If they do not exist (i.e. first time running),
 * we will set it to the default values.
 */
void MainWindow::setupSettings()
{
    // Check if colored event setting does not exist
    if (!userSettings.contains("coloredEventOutput") || !userSettings.value("coloredEventOutput").isValid()) {
        // set the default value
        userSettings.setValue("coloredEventOutput", INITIAL_COLORED_EVENTS_OUTPUT);
    }

    //set session variable based on setting
    coloredEventOutput = userSettings.value("coloredEventOutput").toBool();

    //set gui display to match
    ui->colored_events_output->setChecked(coloredEventOutput);

    //==============================================================

    //check if user has not set a custom logfile directory
    if ( userSettings.value("logfileLocation").toString().isEmpty() || !userSettings.contains("logfileLocation"))
    {
        //initialize default setting
        userSettings.setValue("logfileLocation", QCoreApplication::applicationDirPath() + "/" + INITIAL_LOGFILE_LOCATION);
    }

    // Ensure the directory exists and create it if not
    QDir logDir(userSettings.value("logfileLocation").toString());
    if (!logDir.exists())
    {
        if (!logDir.mkpath("."))
        {
            qDebug() << "Error: setupSettings Failed to create logfile directory: " << userSettings.value("logfileLocation").toString();
            notifyUser("Failed to create logfile directory",userSettings.value("logfileLocation").toString(), true );
        }
    }

    //==============================================================

    // Check if advanced log file setting does not exist
    if (!userSettings.contains("advancedLogFile") || !userSettings.value("advancedLogFile").isValid()) {
        // set the default value
        userSettings.setValue("advancedLogFile", INITIAL_ADVANCED_LOG_FILE);
    }

    //set session variable based on setting
    advancedLogFile = userSettings.value("advancedLogFile").toBool();

    //set gui display to match
    ui->advanced_log_file->setChecked(advancedLogFile);

    //==============================================================

    // Check if the cleared error notification setting does not exist
    if (!userSettings.contains("notifyOnErrorCleared") || !userSettings.value("notifyOnErrorCleared").isValid()) {
        // set the default value
        userSettings.setValue("notifyOnErrorCleared", INITIAL_NOTIFY_ON_ERROR_CLEARED);
    }

    //set session variable based on setting
    notifyOnErrorCleared = userSettings.value("notifyOnErrorCleared").toBool();

    //update gui to match
    ui->notify_error_cleared->setChecked(notifyOnErrorCleared);

    //==============================================================

    // Check if the auto save setting does not exist
    if (!userSettings.contains("autoSaveLimit") || !userSettings.value("autoSaveLimit").isValid()) {
        // set the default value
        userSettings.setValue("autoSaveLimit", INITIAL_AUTO_SAVE_LIMIT);
    }

    //set session variable based on setting
    autoSaveLimit = userSettings.value("autoSaveLimit").toInt();

    //update gui to match
    ui->auto_save_limit->setValue(autoSaveLimit);

    //==============================================================

    //check if the timeout setting does not exist
    if (!userSettings.contains("connectionTimeout") || !userSettings.value("connectionTimeout").isValid()) {
        // If it doesn't exist or is not valid, set the default value
        userSettings.setValue("connectionTimeout", INITIAL_CONNECTION_TIMEOUT);
    }

    //set session variable based on setting
    connectionTimeout = userSettings.value("connectionTimeout").toInt();

    //update gui to match
    ui->connection_timeout->setValue(connectionTimeout);

    //dont allow the user to go below this value for max data nodes
    ui->connection_timeout->setMinimum(MIN_TIMEOUT_DURATION);

    //==============================================================

    // Check if ram clearing setting does not exist
    if (!userSettings.contains("RAMClearing") || !userSettings.value("RAMClearing").isValid()) {
        // set the default value
        userSettings.setValue("RAMClearing", INITIAL_RAM_CLEARING);
    }

    //set gui display to match
    ui->ram_clearing->setChecked(userSettings.value("RAMClearing").toBool());

    //check if the max nodes setting does not exist
    if (!userSettings.contains("maxDataNodes") || !userSettings.value("maxDataNodes").isValid()) {
        // If it doesn't exist or is not valid, set the default value
        userSettings.setValue("maxDataNodes", INITIAL_MAX_DATA_NODES);
    }

    //update gui to match
    ui->max_data_nodes->setValue(userSettings.value("maxDataNodes").toInt());

    //dont allow the user to go below this value for max data nodes
    ui->max_data_nodes->setMinimum(MIN_DATA_NODES_BEFORE_RAM_CLEAR);

    //set max node visibility based on ram clearing setting
    ui->max_data_nodes->setVisible(userSettings.value("RAMClearing").toBool());
    ui->max_data_nodes_label->setVisible(userSettings.value("RAMClearing").toBool());

    //==============================================================

    //sets up text options in connection settings drop down boxes
    setupConnectionPage();

    //setup port name selections on gui (scans for available ports)
    setup_ddm_port_selection(0);

    #if DEV_MODE
        //load port names for csim port selection
        setup_csim_port_selection(0);

        #if GENERAL_DEBUG
        // Display user settings
        displaySavedSettings();
        #endif
    #endif

    //in case settings were loaded from initial constants, sync settings to registry
    userSettings.sync();
}

/**
 * @brief Updates the GUI status page with the current values of the Status class
 *
 * Includes the feed position graphic, fire mode graphic, fire rate, number of firing
 * events, burst length, processor state, trigger status' and graphics, and the armed
 * status and graphic
 */
void MainWindow::updateStatusDisplay()
{
    //update feed position text and graphic
    ui->feedPosition->setValue(status->feedPosition);
    ui->feed_position_label->setText(FEED_POSITION_NAMES[status->feedPosition/FEED_POSITION_INCREMENT_VALUE]);

    //update fire mode graphic
    ui->fireMode->setValue(status->firingMode);

    //update text (fire rate, firing events, burst length, processor state)
    ui->fireRateOutput->setText(QString::number(status->firingRate));
    ui->firingEventsOutput->setText(QString::number(status->totalFiringEvents));
    ui->burstOutput->setText(QString::number(status->burstLength));
    ui->processorOutput->setText(CONTROLLER_STATE_NAMES[status->controllerState]);

    //update trigger 1 text
    ui->trigger1_label->setText(TRIGGER_STATUS_NAMES[status->trigger1]);

    //update trigger 1 graphic
    switch (status->trigger1)
    {
    case ENGAGED:
        ui->trigger1->setPixmap(GREEN_LIGHT);

        break;

    case DISENGAGED:
        ui->trigger1->setPixmap(RED_LIGHT);

        break;

    default:
        ui->trigger1->setPixmap(BLANK_LIGHT);
    }

    //update trigger 2 text
    ui->trigger2_label->setText(TRIGGER_STATUS_NAMES[status->trigger2]);

    //update trigger 2 graphic
    switch (status->trigger2)
    {
        case ENGAGED:
            ui->trigger2->setPixmap(GREEN_LIGHT);
            break;

        case DISENGAGED:
            ui->trigger2->setPixmap(RED_LIGHT);
            break;

        default:
            ui->trigger2->setPixmap(BLANK_LIGHT);
    }

    //update armed text
    ui->armed_label->setText(ARMED_NAMES[status->armed]);

    //update the armed graphic
    if(status->armed)
    {
        ui->armedOutput->setPixmap(GREEN_LIGHT);
    }
    else
    {
        ui->armedOutput->setPixmap(RED_LIGHT);
    }
}

/**
 * @brief Updates the running elapsed controller time on GUI
 *
 * NOTE: Ran every second
 */
void MainWindow::updateElapsedTime()
{
    // add 1 second to timer
    status->elapsedControllerTime = status->elapsedControllerTime.addSecs(1);

    // update the GUI
    ui->elapsedTime->setText(status->elapsedControllerTime.toString(TIME_FORMAT));
}

/**
 * @brief Updates the running time since last message receieved to DDM on GUI
 *
 * NOTE: Ran every second
 */
void MainWindow::updateTimeSinceLastMessage()
{
    //safety in case timer is left running after disconnect
    if (!ddmCon->connected )
    {
        lastMessageTimer->stop();
        qDebug() << "Error: updateTimeSinceLastMessage, lastMessageTimer is running after disconnect" << Qt::endl;
        return;
    }

    // initialize variables
    QTime elapsedTime;

    // calculate time elapsed since the last time DDM received a message
    QDateTime currentTime = QDateTime::currentDateTime();

    // the msecsto method returns the amount of ms from timeLastRecieved to currentTime
    qint64 elapsedMs = timeLastReceived.msecsTo(currentTime);

    // check for negative elapsed time
    if(elapsedMs < 0)
    {
        qDebug() << "Error: updateTimeSinceLastMessage time since last DDM message received is negative."<< Qt::endl;
    }
    //check if timeout was reached
    else if (elapsedMs >= connectionTimeout)
    {
        //notify timeout
        notifyUser("Connection timeout", "We have not received a message from the controller in "
                    + QString::number(connectionTimeout) +" msec. (you can "
                    "modify this from settings page)", true);

        //run disconnect method
        on_handshake_button_clicked();
    }
    // assume positive elapsed time
    else
    {
        // convert back into QTime instead of qint64
        elapsedTime = QTime(0, 0, 0).addMSecs(elapsedMs);

        // update gui
        ui->DDMTimer->setText(elapsedTime.toString(TIME_FORMAT));
    }
}

/**
 * @brief Appends to the events text box on the GUI and dynamically colors output
 *
 * This method determines the type of message it is, and outputs it to the text box on the
 * GUI with color coding depending on its type. It also validates if any filters are set.
 *
 * @param event A pointer to the eventNode containing the message information
 */
void MainWindow::updateEventsOutput(EventNode *event)
{
    QTextDocument document;
    QString richText;
    QString outString = events->nodeToString(event);

    //check if we have an event as input and check if filter allows printing events
    if (!event->isError() )
    {
        if (eventFilter == EVENTS || eventFilter == ALL)
        {
            //change output text color to white
            richText = "<p style='color: "+EVENT_COLOR+"; font-size: "+EVENT_OUTPUT_SIZE+"px'>"+ outString + "</p>";

            //activate html for the output
            document.setHtml(richText);

            //append styled string to the events output
            ui->events_output->append(document.toHtml());
        }
    }
    //otherwise check for cleared error and if filter allows printing cleared errors
    else if (static_cast<ErrorNode *>(event)->cleared)
    {
        if (eventFilter == ALL || eventFilter == ERRORS || eventFilter == CLEARED_ERRORS)
        {
            if (coloredEventOutput)
            {
                //change output text color to green
                richText = "<p style='color: "+CLEARED_ERROR_COLOR+"; font-size: "+EVENT_OUTPUT_SIZE+"px'>"+ outString + "</p>";
            }
            else
            {
                //change output text color to white
                richText = "<p style='color: "+EVENT_COLOR+"; font-size: "+EVENT_OUTPUT_SIZE+"px'>"+ outString + "</p>";
            }

            //activate html for the output
            document.setHtml(richText);

            //append styled string to the events output
            ui->events_output->append(document.toHtml());
        }
    }
    //otherwise this is a non-cleared error check if filtering allows printing non-cleared errors
    else if (eventFilter == ALL || eventFilter == NON_CLEARED_ERRORS || eventFilter == ERRORS)
    {
        if (coloredEventOutput)
        {
            //change output text color to red
            richText = "<p style='color: "+ACTIVE_ERROR_COLOR+"; font-size: "+EVENT_OUTPUT_SIZE+"px'>"+ outString + "</p>";
        }
        else
        {
            //change output text color to white
            richText = "<p style='color: "+EVENT_COLOR+"; font-size: "+EVENT_OUTPUT_SIZE+"px'>"+ outString + "</p>";
        }

        //activate html for the output
        document.setHtml(richText);

        //append styled string to the events output
        ui->events_output->append(document.toHtml());
    }

    // update total events gui
    ui->TotalEventsOutput->setText(QString::number(events->totalEvents));
    ui->statusEventOutput->setText(QString::number(events->totalEvents));

    if (!event->isError()) return;

    // update total errors gui
    ui->TotalErrorsOutput->setText(QString::number(events->totalErrors));
    ui->statusErrorOutput->setText(QString::number(events->totalErrors));

    if ( static_cast<ErrorNode *>(event)->cleared )
    {
        // update cleared errors gui
        ui->ClearedErrorsOutput->setText(QString::number(events->totalClearedErrors));
        ui->statusClearedErrors->setText(QString::number(events->totalClearedErrors));
    }
    else
    {
        // update active errors gui
        ui->ActiveErrorsOutput->setText(QString::number(events->totalErrors - events->totalClearedErrors));
    }
}

/**
 * @brief Empties the entire events text box on the GUI and repopulates it with the current data
 */
void MainWindow::refreshEventsOutput()
{
    // reset gui element
    ui->events_output->clear();

    //init vars
    ErrorNode *wkgErrPtr = events->headErrorNode;
    EventNode *wkgEventPtr = events->headEventNode;
    EventNode *nextPrintPtr;

    //loop through all events and errors
    while(wkgErrPtr != nullptr || wkgEventPtr != nullptr)
    {
        // get next to print
        nextPrintPtr = events->getNextNode(wkgEventPtr, wkgErrPtr);

        //update events output if filter allows
        updateEventsOutput(nextPrintPtr);
    }

    #if DEV_MODE && GUI_DEBUG
    qDebug() << "Events output refreshed";
    #endif
}

/**
 * @brief Clears an error from the events output by replacing the active/cleared indicator
 * @param errorId The ID of the error to be cleared
 */
void MainWindow::clearErrorFromEventsOutput(int errorId)
{
    //if user is on specific error filter, refresh to update their screen
    if (eventFilter == NON_CLEARED_ERRORS || eventFilter == CLEARED_ERRORS)
    {
        refreshEventsOutput();
        return;
    }

    QTextCharFormat newColor;
    if (coloredEventOutput)
    {
        newColor.setForeground(QColor(20, 174, 92));
    }

    // Get the QTextDocument of the QTextEdit
    QTextDocument *document = ui->events_output->document();

    // Create a QTextCursor to manipulate the text
    QTextCursor cursor(document);

    // Move to the beginning of the document
    cursor.movePosition(QTextCursor::Start);

    cursor = document->find("ID: " + QString::number(errorId) + ",", cursor, QTextDocument::FindWholeWords);
    if (!cursor.isNull())
    {
        if (coloredEventOutput)
        {
            //store our starting place
            QTextCursor tmpCursor = cursor;

            //highlight the entire line
            cursor.movePosition(QTextCursor::EndOfLine, QTextCursor::KeepAnchor);

            // Apply new color to the highlighted text
            cursor.mergeCharFormat(newColor);

            //move cursor to prev position
            cursor = tmpCursor;
        }

        //find active error indicator
        cursor = document->find(events->activeIndicator, cursor, QTextDocument::FindWholeWords);
        // Replace active indicator with cleared indicator
        cursor.insertText(events->clearedIndicator);

        #if DEV_MODE && (EVENTS_DEBUG || GUI_DEBUG)
        qDebug() << "Cleared error " << errorId << " on events output";
        #endif
    }
    else
    {
        qDebug() << "Error: clearErrorFromEventsOutput failed to find error" << errorId << Qt::endl;
    }
}

/**
 * @brief Notifies the user with a notification on the GUI
 *
 * Overloaded method
 *
 * @param notificationText The string message to display to the user
 * @param error A boolean indicating whether the notification represents an error
 */
void MainWindow::notifyUser(QString notificationText, bool error)
{
    notifyUser(notificationText, "", error);
}

/**
 * @brief Notifies the user with a notification on the GUI
 *
 * The notification is rendered for the user for a few seconds. If it is an error,
 * this is considered "urgent" and there will be a red indicator on the notification
 * bell indicating that there is an unread error message.
 *
 * @param notificationText The string message to display to the user
 * @param logText Log information to be displayed
 * @param error A boolean indicating whether the notification represents an error
 */
void MainWindow::notifyUser(QString notificationText, QString logText, bool error)
{
    // Get the current timestamp
    QString timeStamp = QDateTime::currentDateTime().toString("[" + TIME_FORMAT +"] ");

    QString notificationRichText = "<p style='" + NOTIFICATION_TIMESTAMP_STYLE + "'>" + timeStamp +
                                   " " + "<span style='color: ";

    QString popUpStyle = "border: 3px solid ";

    // get new lines as literals
    notificationText.replace("\n", "\\n");

    if (error)
    {
        //replace new line literals with \n symbols
        logText.replace("\n", "\\n");
        notificationRichText += ERROR_COLOR;
        popUpStyle += ERROR_COLOR;
    }
    else
    {
        notificationRichText += STANDARD_COLOR;
        popUpStyle += STANDARD_COLOR;
    }
    notificationRichText += "; font-size: "+NOTIFICATION_SIZE+"px'>" + notificationText;
    popUpStyle += "; " + POP_UP_STYLE;

    if (logText != "")
    {
        notificationRichText += " : " + logText;
    }
    notificationRichText+= + "</span></p>";

    //set pop up style
    ui->notificationPopUp->setStyleSheet(popUpStyle);

    //add full notification to notification page output
    ui->notificationOutput->append(notificationRichText);

    //display notification on "navbar"
    ui->notificationPopUp->setText(notificationText);

    //check if user is on notification page, and if this is an error
    if (ui->Flow_Label->currentIndex() != 6 && error)
    {
        //update the notification icon to get user attention
        ui->NotificationPageButton->setStyleSheet(URGENT_NOTIFICATION_ICON);
    }

    //stop old timer if running
    notificationTimer->stop();

    //give fresh timeout to avoid premature notification clearing
    notificationTimer->start(NOTIFICATION_DURATION);
}

/**
 * @brief Generates statistics for a session
 *
 * Includes various information that may be important such as duration and
 * total counters.
 *
 * @return QString The session statistics formatted as a string
 */
QString MainWindow::getSessionStatistics()
{
    return "Duration: " + status->elapsedControllerTime.toString(TIME_FORMAT) + ", Total Events: " +
           QString::number(events->totalEvents) + ", Total Errors: " + QString::number(events->totalErrors)
           + ", Non-cleared errors: " + QString::number(events->totalClearedErrors)
           + ", Total Firing events: " + QString::number(status->totalFiringEvents);
}

/**
 * @brief Logs advanced details into the log file
 *
 * Logs status updates and electrical data when advanced setting is checked
 *
 * @param id The identifier for the type of message to log
 */
void MainWindow::logAdvancedDetails(SerialMessageIdentifier id)
{
    if (autosaveLogFile == "")
    {
        return;
    }

    //retreive the given file
    QFile file(autosaveLogFile);
    QString outString;

    //get proper msg id
    switch(id)
    {
        case ELECTRICAL:
            outString = ADVANCED_LOG_FILE_INDICATOR + "Electrical Data: " + electricalData->toString();

            break;

        case STATUS:
            outString = ADVANCED_LOG_FILE_INDICATOR + "Status Update: " + status->toString();

            break;

        case CLOSING_CONNECTION:
            outString = ADVANCED_LOG_FILE_INDICATOR + "Session Statistics: " + getSessionStatistics();

            break;

        default:
            break;
    }

    //attempt to open in append mode
    if (!file.open(QIODevice::Append | QIODevice::Text))
    {
        qDebug() <<  "Error: logAdvancedDetails Could not open log file for appending: " << autosaveLogFile << Qt::endl;
        notifyUser("Failed to open logfile", "log text \"" + outString + "\" discarded", true);
    }
    else
    {
        //append the text to the log file
        QTextStream out(&file);
        out << outString << Qt::endl;
        file.close();
    }
}

/**
 * @brief Dynamically populates the eletrical page using data from the Electrical class
 *
 * This method renders the widgets for displaying the electrical boxes side by side in
 * the GUI. Each electrical box corresponds to a node in the linked list
 */
void MainWindow::renderElectricalPage()
{
    if (electricalData->headNode == nullptr)
    {
        notifyUser("No electrical Data to display", false);
        return;
    }

    // Get the parent container into a widget object
    QWidget *elecParentContainer = ui->scrollAreaWidgetContents;

    // Find the existing vertical layout of elecParentContainer
    QVBoxLayout *verticalLayout = qobject_cast<QVBoxLayout*>(elecParentContainer->layout());

    // Check if the vertical layout already exists
    if (verticalLayout)
    {
        // Set the alignment of the vertical layout to top
        verticalLayout->setAlignment(Qt::AlignTop);

        // Set the margins of the scroll area's contents
        verticalLayout->setSpacing(0);

        //get wkg pointer at head of electrical ll
        electricalNode *wkgPtr = electricalData->headNode;

        //loop through the electrical linked list
        while (wkgPtr != nullptr)
        {
            // create a horizontal widget (for displaying 2 electrical boxes side by side)
            QWidget *horizontalWidget = new QWidget(elecParentContainer);

            // create a layout for the horizontal widget
            QHBoxLayout *horizontalLayout = new QHBoxLayout(horizontalWidget);

            //remove pre set spacing
            horizontalLayout->setContentsMargins(0, 0, 0, 0);
            horizontalLayout->setSpacing(0);

            //add a box for this node
            addElecBox(horizontalWidget, horizontalLayout, wkgPtr);

            //get next node
            wkgPtr=wkgPtr->nextNode;

            //check if we have not reached end of ll
            if (wkgPtr != nullptr)
            {
                //add next box to the horizontal layout
                addElecBox(horizontalWidget, horizontalLayout, wkgPtr);

                //get next node
                wkgPtr = wkgPtr->nextNode;
            }

            // Set the horizontal layout for the widget
            horizontalWidget->setLayout(horizontalLayout);

            // Add the horizontal widget to the existing vertical layout
            verticalLayout->addWidget(horizontalWidget);
        }
    }
    else
    {
        // Vertical layout doesn't exist, handle error or create it
        qDebug() << "Error: renderElectricalPage No vertical layout found for elecParentContainer";
        notifyUser("Error rendering electrical page", "Turn on advanced log file on settings page to view electrical data at the end of the session",true);
    }
}

/**
 * @brief Adds an electrical box widget to the layout
 * @param horizontalWidget The parent horizontal widget
 * @param horizontalLayout The horizontal layout to which the box will be added to
 * @param component The eletrical node containing the data to be displayed in the box
 */
void MainWindow::addElecBox(QWidget *horizontalWidget, QLayout *horizontalLayout, electricalNode *component)
{
    //Create vertical layout (for header on top of content)
    QWidget *elecBox = new QWidget(horizontalWidget);
    QVBoxLayout *elecBoxLayout = new QVBoxLayout(elecBox);
    elecBoxLayout->setContentsMargins(3, 0, 3, 13);
    elecBoxLayout->setSpacing(0);
    elecBoxLayout->setAlignment(Qt::AlignTop);

    //create box header
    QLabel *elecBoxTitle = new QLabel(component->name, elecBox);
    elecBoxTitle->setStyleSheet(ELECTRICAL_BOX_HEADER_STYLE);
    elecBoxTitle->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed); // Set expanding size policy
    elecBoxTitle->setFixedHeight(75);
    elecBoxTitle->setMargin(5);
    elecBoxLayout->addWidget(elecBoxTitle);

    //create box content
    QTextEdit *elecBoxContent = new QTextEdit( elecBox);
    elecBoxContent->setAlignment(Qt::AlignCenter);
    elecBoxContent->setPlainText("Voltage: " + QString::number(component->voltage) +
                                 "\nAmps: " + QString::number(component->amps));
    elecBoxContent->setStyleSheet(ELECTRICAL_BOX_CONTENT_STYLE);
    elecBoxContent->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed); // Set expanding size policy
    elecBoxContent->setFixedHeight(100);

    //add box to layout
    elecBoxLayout->addWidget(elecBoxContent);
    elecBox->setLayout(elecBoxLayout);
    horizontalLayout->addWidget(elecBox);
}

/**
 * @brief Frees the memory allocated for widgets in the electrical page
 *
 * Iterates over all child widgets in the electrical scroll area and deletes them
 */
void MainWindow::freeElectricalPage()
{
    QWidget *scrollAreaWidgetContents = ui->scrollAreaWidgetContents;

    // Iterate over all children of scrollAreaWidgetContents
    QList<QWidget*> children = scrollAreaWidgetContents->findChildren<QWidget*>();
    for (QWidget *child : children) {
        // Check if the child is not the scrollAreaWidgetContents itself
        if (child != scrollAreaWidgetContents) {
            child->deleteLater(); // Schedule the child widget for deletion
        }
    }
}

/**
 * @brief Handles the RAM clear event that clears memory for performance
 *
 * This slot is triggered in response to the RAMCleared signal emitted by
 * the events class.
 */
void MainWindow::handleRAMClear()
{
    notifyUser("RAM Cleared",
               "Events and errors were removed from RAM to improve performance. "
               "They are still being tracked by counters and our log file. You can also load them"
               " back into the GUI after this session ends.", false);

    //show truncated label on the events page to tell user not all nodes are displayed
    ui->truncated_label->setVisible(true);

    //get rid of outdated display
    refreshEventsOutput();
}

//======================================================================================
//DEV_MODE exclusive methods
//======================================================================================

#if DEV_MODE
/**
 * @brief Scans for available serial ports and adds them to the CSIM selection box
 * @param index The index of the selected item in the selection box
 */
void MainWindow::setup_csim_port_selection(int index)
{
    // Check and set initial value for "csimPortName"
    if (userSettings.value("csimPortName").toString().isEmpty())
        userSettings.setValue("csimPortName", INITIAL_CSIM_PORT);

    ui->csim_port_selection->clear();

    // Fetch available serial ports and add their names to the combo box
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        QString portName = info.portName();
        ui->csim_port_selection->addItem(portName);

        // Check if the current port name matches the one declared in settings
        if (portName == userSettings.value("csimPortName").toString())
        {
            // If a match is found, set the current index of the combo box
            ui->csim_port_selection->setCurrentIndex(ui->csim_port_selection->count() - 1);
        }
    }
}

/**
 * @brief Updates the non-cleared error selection box
 */
void MainWindow::update_non_cleared_error_selection()
{
    //clear combo box
    ui->non_cleared_error_selection->clear();

    //check for valid events ptr
    if (csimHandle->eventsPtr != nullptr)
    {
        //get head node
        ErrorNode *wkgPtr = csimHandle->eventsPtr->headErrorNode;

        //loop until list ends
        while (wkgPtr != nullptr)
        {
            //add the uncleared error to the combo box
            ui->non_cleared_error_selection->addItem(QString::number(wkgPtr->id) + DELIMETER + wkgPtr->eventString);

            //get next error
            wkgPtr = wkgPtr->nextPtr;
        }
    }
}

/**
 * @brief Writes an empty line to QDebug
 */
void MainWindow::logEmptyLine()
{
    //revert to standard output format
    qSetMessagePattern("%{message}");

    //log empty line
    qDebug();

    //enable custom message format
    qSetMessagePattern(QDEBUG_OUTPUT_FORMAT);
}

/**
 * @brief Outputs user settings values to QDebug
 */
void MainWindow::displaySavedSettings()
{
    logEmptyLine();
    qDebug() << "Connection Settings Saved Cross Session:";
    // Print the values of each setting
    qDebug() << "DDM Port: " << userSettings.value("portName").toString();
    qDebug() << "CSIM Port: " << userSettings.value("csimPortName").toString();
    qDebug() << "baudRate:" << userSettings.value("baudRate").toString();
    qDebug() << "dataBits:" << userSettings.value("dataBits").toString();
    qDebug() << "parity:" << userSettings.value("parity").toString();
    qDebug() << "stopBits:" << userSettings.value("stopBits").toString();
    qDebug() << "flowControl:" << userSettings.value("flowControl").toString();
    qDebug() << "logfile location: " << userSettings.value("logfileLocation").toString();
    qDebug() << "Colored Event Output: " << userSettings.value("coloredEventOutput").toBool();
    qDebug() << "Auto Save Limit: " << userSettings.value("autoSaveLimit").toInt();
    qDebug() << "Notify on error cleared: " << userSettings.value("notifyOnErrorCleared").toBool();
    qDebug() << "Advanced log file: " << userSettings.value("advancedLogFile").toBool();
    qDebug() << "Connection Timeout duration: " << userSettings.value("connectionTimeout").toInt();
    qDebug() << "RAM Clearing: " << userSettings.value("RAMClearing").toBool();
    qDebug() << "Max Data Nodes: " << userSettings.value("maxDataNodes").toInt() << Qt::endl;
}
#endif

